"use client";

import { useState, useEffect } from "react";

interface Slide {
  image: string;
  title: string;
  desc: string;
}

interface CarouselProps {
  slides: Slide[];
  autoPlay?: boolean;
  interval?: number;
  className?: string;
}

export default function Carousel({ 
  slides, 
  autoPlay = true, 
  interval = 5000,
  className = "" 
}: CarouselProps) {
  const [currentSlide, setCurrentSlide] = useState(0);

  useEffect(() => {
    if (!autoPlay) return;
    
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, interval);
    
    return () => clearInterval(timer);
  }, [autoPlay, interval, slides.length]);

  const goToSlide = (index: number) => {
    setCurrentSlide(index);
  };

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % slides.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length);
  };

  return (
    <div className={`relative overflow-hidden rounded-3xl ${className}`}>
      {/* اسلایدها */}
      <div 
        className="relative h-full transition-all duration-700 ease-out"
        style={{ height: '100%' }}
      >
        {slides.map((slide, index) => (
          <div
            key={index}
            className={`absolute inset-0 transition-all duration-700 ${
              currentSlide === index 
                ? "opacity-100 translate-x-0" 
                : "opacity-0 translate-x-full"
            }`}
            style={{
              transform: currentSlide === index 
                ? 'translateX(0)' 
                : currentSlide > index 
                ? 'translateX(-100%)' 
                : 'translateX(100%)'
            }}
          >
            {/* تصویر پس‌زمینه */}
            <img
              src={slide.image}
              alt={slide.title}
              className="w-full h-full object-cover"
            />
            
            {/* گرادینت روی تصویر */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent" />
            
            {/* محتوای اسلاید */}
            <div className="absolute bottom-12 left-0 right-0 text-center px-6 z-10">
              <div className="inline-block px-4 py-1.5 rounded-full bg-white/20 backdrop-blur-md text-white text-xs font-medium mb-3">
                اینستا‌کلون
              </div>
              <h2 className="text-2xl md:text-3xl font-bold text-white mb-2 drop-shadow-lg">
                {slide.title}
              </h2>
              <p className="text-white/80 text-sm md:text-base max-w-xs mx-auto">
                {slide.desc}
              </p>
            </div>
          </div>
        ))}
      </div>

      {/* دکمه قبلی */}
      <button
        onClick={prevSlide}
        className="absolute left-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/30 backdrop-blur-md text-white hover:bg-black/50 transition-all duration-300 flex items-center justify-center z-20"
      >
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
        </svg>
      </button>

      {/* دکمه بعدی */}
      <button
        onClick={nextSlide}
        className="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/30 backdrop-blur-md text-white hover:bg-black/50 transition-all duration-300 flex items-center justify-center z-20"
      >
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
        </svg>
      </button>

      {/* دکمه‌های ناوبری (نقاط) */}
      <div className="absolute bottom-28 left-0 right-0 flex justify-center gap-2 z-20">
        {slides.map((_, index) => (
          <button
            key={index}
            onClick={() => goToSlide(index)}
            className={`h-1.5 rounded-full transition-all duration-300 ${
              currentSlide === index 
                ? "w-8 bg-white" 
                : "w-4 bg-white/40 hover:bg-white/60"
            }`}
          />
        ))}
      </div>
    </div>
  );
}