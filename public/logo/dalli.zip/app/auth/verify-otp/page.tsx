"use client";

import { Check, CircleCheck, Clock8, MoveLeft, RefreshCw } from "lucide-react";
import Image from "next/image";
import { useState, useRef, useEffect } from "react";
import toast from "react-hot-toast";

interface VerifyOtpFormProps {
  phone: string;
  onBack: () => void;
  onVerify: (code: string) => void;
}

export default function VerifyOtpForm({
  phone,
  onBack,
  onVerify,
}: VerifyOtpFormProps) {
  const [otp, setOtp] = useState(["", "", "", "", "", ""]);
  const [isLoading, setIsLoading] = useState(false);
  const [timeLeft, setTimeLeft] = useState(120);
  const [focusedIndex, setFocusedIndex] = useState<number | null>(null);
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

  useEffect(() => {
    if (inputRefs.current[0]) {
      inputRefs.current[0].focus();
    }
  }, []);

  useEffect(() => {
    if (timeLeft <= 0) return;
    const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
    return () => clearTimeout(timer);
  }, [timeLeft]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  const handleOtpChange = (index: number, value: string) => {
    if (value.length > 1) return;
    if (!/^\d*$/.test(value)) return;

    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);

    if (value && index < 5) {
      inputRefs.current[index + 1]?.focus();
    }

    if (value && index === 5 && newOtp.every((d) => d !== "")) {
      setTimeout(() => handleVerify(), 300);
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === "Backspace" && !otp[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
    }
  };

  const handleVerify = () => {
    const code = otp.join("");
    if (code.length !== 6) {
      toast.error("  کد 6 رقمی را کامل وارد کنید!");
      return;
    }
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      toast.success("  ورود موفقیت‌آمیز!");
      onVerify(code);
    }, 1000);
  };

  const handleResendCode = () => {
    setTimeLeft(120);
    setOtp(["", "", "", "", "", ""]);
    toast.success("  کد جدید ارسال شد!");
    if (inputRefs.current[0]) {
      inputRefs.current[0].focus();
    }
  };

  return (
    <div className="space-y-6">
      {/* لوگو با آیکون */}
      <div className="flex justify-center">
        <div className="relative group">
          <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-red-400 to-pink-500 blur-xl opacity-60 group-hover:opacity-100 transition-opacity duration-500"></div>
        <div className="relative w-20 h-20 rounded-2xl bg-gray-200 dark:bg-gray-200 flex items-center justify-center shadow-xl transform group-hover:scale-110 transition-all duration-500">
            <Image
              src="/logo/org.png"
              alt="Picture of the author"
              width={70}
              height={70}
            />
          </div>
        </div>
      </div>

      {/* متن تایید */}
      <div className="text-center">
        <h3 className="text-2xl font-bold bg-gradient-to-r from-gray-800 to-gray-600 dark:from-white dark:to-gray-300 bg-clip-text text-transparent">
          تایید دو مرحله‌ای
        </h3>
        <p className="text-gray-500 dark:text-gray-400 text-sm mt-1">
          کد تایید برای
        </p>
        <p className="font-semibold text-blue-600 dark:text-blue-400 text-base mt-1">
          {phone}
        </p>
      </div>

      {/* فیلدهای OTP با افکت جذاب */}
      <div className="space-y-3">
        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 text-center">
          کد 6 رقمی را وارد کنید
        </label>
        <div className="flex justify-center gap-3">
          {otp.map((digit, index) => (
            <div key={index} className="relative">
              <input
                ref={(el) => {
                  inputRefs.current[index] = el;
                }}
                type="text"
                inputMode="numeric"
                maxLength={1}
                value={digit}
                onChange={(e) => handleOtpChange(index, e.target.value)}
                onKeyDown={(e) => handleKeyDown(index, e)}
                onFocus={() => setFocusedIndex(index)}
                onBlur={() => setFocusedIndex(null)}
                className="w-14 h-16 text-center text-2xl font-bold rounded-xl border-2 bg-white dark:bg-gray-800 text-gray-900 dark:text-white outline-none transition-all duration-200"
                style={{
                  borderColor: digit
                    ? "#10B981"
                    : focusedIndex === index
                      ? "#3B82F6"
                      : "#E5E7EB",
                  boxShadow:
                    focusedIndex === index
                      ? "0 0 0 3px rgba(59, 130, 246, 0.1)"
                      : digit
                        ? "0 0 0 3px rgba(16, 185, 129, 0.1)"
                        : "none",
                  transform:
                    focusedIndex === index ? "scale(1.05)" : "scale(1)",
                }}
              />
              {digit && (
                <div className="absolute -top-2 -right-2 w-5 h-5 rounded-full bg-green-500 flex items-center justify-center animate-bounce">
                   <Check />
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* تایمر با آیکون */}
      <div className="text-center">
        {timeLeft > 0 ? (
          <div className="flex items-center justify-center gap-2 text-sm text-gray-500 dark:text-gray-400">
           <Clock8 />
            <span>زمان باقیمانده</span>
            <span className="font-mono font-bold text-blue-600 dark:text-blue-400 text-base">
              {formatTime(timeLeft)}
            </span>
          </div>
        ) : (
          <button
            onClick={handleResendCode}
            className="text-sm cursor-pointer text-blue-600 dark:text-blue-400 hover:text-blue-700 font-medium transition-colors flex items-center justify-center gap-2 mx-auto"
          >
           <RefreshCw />
            <span>ارسال مجدد کد</span>
          </button>
        )}
      </div>

      {/* دکمه تایید با آیکون */}
      <button
        onClick={handleVerify}
        disabled={isLoading}
        className="relative cursor-pointer w-full py-3.5 rounded-xl font-bold text-white overflow-hidden group transition-all duration-300 transform hover:scale-[1.02] active:scale-95 disabled:opacity-60 disabled:cursor-not-allowed"
      >
        <div className="absolute inset-0 bg-gradient-to-r from-red-500 via-red-600 to-pink-600 group-hover:from-red-600 group-hover:via-red-700 group-hover:to-pink-700 transition-all duration-500"></div>
        <div className="absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-700 bg-gradient-to-r from-transparent via-white/20 to-transparent"></div>

        <span className="relative z-10 flex items-center justify-center gap-2">
          {isLoading ? (
            <>
              <svg
                className="animate-spin h-5 w-5"
                fill="none"
                viewBox="0 0 24 24"
              >
                <circle
                  className="opacity-25"
                  cx="12"
                  cy="12"
                  r="10"
                  stroke="currentColor"
                  strokeWidth="4"
                ></circle>
                <path
                  className="opacity-75"
                  fill="currentColor"
                  d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                ></path>
              </svg>
              <span>در حال تایید...</span>
            </>
          ) : (
            <>
               <CircleCheck />
              <span>تایید و ورود</span>
            </>
          )}
        </span>
      </button>

      {/* دکمه بازگشت با آیکون */}
      <button
        onClick={onBack}
        className="w-full cursor-pointer py-2 rounded-xl font-medium text-gray-500 dark:text-gray-400 hover:text-blue-600 dark:hover:text-blue-400 transition-all duration-200 flex items-center justify-center gap-2 group"
      >
          <span>تغییر شماره موبایل</span>
         <MoveLeft />
       
      </button>
    </div>
  );
}
