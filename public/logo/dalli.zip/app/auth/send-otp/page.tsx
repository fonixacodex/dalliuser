"use client";

import { Check, CheckCheck, Phone, Send } from "lucide-react";
import Image from "next/image";
import { useState } from "react";
import toast from "react-hot-toast";

interface SendOtpFormProps {
  onSendOtp: (phone: string) => void;
}

export default function SendOtpForm({ onSendOtp }: SendOtpFormProps) {
  const [phone, setPhone] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isFocused, setIsFocused] = useState(false);

 

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value;
    // حذف همه کاراکترهای غیر عددی
    value = value.replace(/[^0-9]/g, '');
    // محدودیت به 11 رقم
    if (value.length <= 11) {
      setPhone(value);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    // بررسی دقیق شماره موبایل ایران
    if (!phone.match(/^09[0-9]{9}$/)) {
      toast.error("📱 شماره موبایل نامعتبر است! (مثال: 09123456789)");
      return;
    }
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      toast.success(" کد تایید ارسال شد!");
      onSendOtp(phone);
    }, 1000);
  };

  // نمایش شماره با فرمت فارسی برای placeholder
  const formatDisplayPhone = (num: string) => {
    const persianDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    return num.replace(/[0-9]/g, (d) => persianDigits[parseInt(d)]);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* لوگو */}
      <div className="flex justify-center">
        <div className="relative group">
          <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-blue-400 to-blue-600 blur-xl opacity-60 group-hover:opacity-100 transition-opacity duration-500"></div>
          <div className="relative w-20 h-20 rounded-2xl bg-gray-200 dark:bg-gray-200 flex items-center justify-center shadow-xl transform group-hover:scale-110 transition-all duration-500">
            <Image
              src="/logo/org.png"
              alt="Logo"
              width={70}
              height={70}
              className="object-contain"
            />
          </div>
        </div>
      </div>

      {/* متن خوش‌آمدید */}
      <div className="text-center">
        <h3 className="text-2xl font-bold bg-gradient-to-r from-gray-800 to-gray-600 dark:from-white dark:to-gray-300 bg-clip-text text-transparent">
          خوش آمدید
        </h3>
        <p className="text-gray-500 dark:text-gray-400 text-sm mt-1">
          برای ورود شماره موبایل خود را وارد کنید
        </p>
      </div>

      {/* فیلد شماره موبایل */}
      <div className="space-y-2">
        <div className={`relative transition-all duration-300 ${isFocused ? "transform scale-[1.02]" : ""}`}>
          
          {/* آیکون سمت راست */}
          <div className="absolute inset-y-0 right-3 flex items-center pointer-events-none z-10 text-blue-400">
           <Phone />
          </div>

          {/* آیکون تایید سمت چپ */}
          {phone.length === 11 && phone.match(/^09[0-9]{9}$/) && (
            <div className="absolute inset-y-0 left-3 flex items-center pointer-events-none z-10 text-green-400">
               <Check />
            </div>
          )}

          

          <input
            type="text"
            value={phone}
            onChange={handlePhoneChange}
            onFocus={() => setIsFocused(true)}
            onBlur={() => setIsFocused(false)}
            placeholder="09123456789"
            className="w-full px-12 py-3.5 rounded-xl border-2 bg-white dark:bg-gray-800 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500 outline-none transition-all duration-300 text-center text-lg font-mono"
            style={{
              borderColor: isFocused
                ? "#3B82F6"
                : phone.length === 11 && phone.match(/^09[0-9]{9}$/)
                  ? "#10B981"
                  : phone.length > 0
                  ? "#F59E0B"
                  : "#E5E7EB",
              boxShadow: isFocused
                ? "0 0 0 4px rgba(59, 130, 246, 0.1)"
                : "none",
            }}
            inputMode="numeric"
            dir="ltr"
          />
        </div>
        
        <div className="flex justify-between items-center px-2">
          <p className="text-xs text-gray-400 dark:text-gray-500">
            مثال: 09123456789
          </p>
          <p className={`text-xs transition-colors duration-300 ${
            phone.length === 0 
              ? 'text-gray-400' 
              : phone.length === 11 && phone.match(/^09[0-9]{9}$/)
              ? 'text-green-500'
              : 'text-orange-500'
          }`}>
            {phone.length === 0 
              ? ' 11 رقم' 
              : phone.length === 11 && phone.match(/^09[0-9]{9}$/)
              ? ' معتبر'
              : ` ${phone.length}/11 رقم`}
          </p>
        </div>
      </div>

      {/* دکمه ارسال */}
      <button
        type="submit"
        disabled={isLoading || phone.length !== 11 || !phone.match(/^09[0-9]{9}$/)}
        className="relative cursor-pointer w-full py-3.5 rounded-xl font-bold text-white overflow-hidden group transition-all duration-300 transform hover:scale-[1.02] active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100"
      >
        <div className="absolute inset-0 bg-gradient-to-r from-blue-500 via-blue-600 to-indigo-600 group-hover:from-blue-600 group-hover:via-blue-700 group-hover:to-indigo-700 transition-all duration-500"></div>
        <div className="absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-700 bg-gradient-to-r from-transparent via-white/20 to-transparent"></div>

        <span className="relative z-10 flex items-center justify-center gap-2">
          {isLoading ? (
            <>
              <svg className="animate-spin h-5 w-5" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              <span>در حال ارسال...</span>
            </>
          ) : (
            <>
            <Send />
              <span>دریافت کد تایید</span>
            </>
          )}
        </span>
      </button>
    </form>
  );
}