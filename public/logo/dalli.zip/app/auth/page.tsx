"use client";

import { useState, useEffect } from "react";
import SendOtpForm from "./send-otp/page";
import VerifyOtpForm from "./verify-otp/page";
import { Moon, Sun } from "lucide-react";

export default function Home() {
  const [step, setStep] = useState<"send" | "verify">("send");
  const [phone, setPhone] = useState("");
  const [isDark, setIsDark] = useState(false);
  const [currentSlide, setCurrentSlide] = useState(0);
  const [mounted, setMounted] = useState(false);

  const slides = [
    {
      image: "/images/1.webp",
      text: "لحظات روزمره را با دوستان نزدیک خود به اشتراک بگذارید"
    },
    {
      image: "/images/2.webp",
      text: "ویدیوهای کوتاه و سرگرم‌کننده را تماشا کنید"
    },
    {
      image: "/images/3.webp",
      text: "با افراد سراسر جهان در ارتباط باشید"
    }
  ];

  useEffect(() => {
    setMounted(true);
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const saved = localStorage.getItem("theme");
    const isDarkMode = saved === "dark";
    setIsDark(isDarkMode);
    if (isDarkMode) {
      document.documentElement.classList.add("dark");
    }
  }, []);

  const toggleTheme = () => {
    const newDark = !isDark;
    setIsDark(newDark);
    if (newDark) {
      document.documentElement.classList.add("dark");
      localStorage.setItem("theme", "dark");
    } else {
      document.documentElement.classList.remove("dark");
      localStorage.setItem("theme", "light");
    }
  };

  const handleSendOtp = (userPhone: string) => {
    setPhone(userPhone);
    setStep("verify");
  };

  const handleVerify = (code: string) => {
    alert(` خوش آمدید!\nکد تایید: ${code}`);
  };

  if (!mounted) return null;

  return (
    <div className="min-h-screen bg-white dark:bg-black transition-colors duration-300">
      
      <button
        onClick={toggleTheme}
        className="fixed top-4 right-4 z-50 p-3 rounded-full bg-gray-100 dark:bg-gray-800 shadow-lg hover:scale-110 transition-all duration-300"
      >
        {isDark ? <Sun className="w-5 h-5 text-yellow-500" /> : <Moon className="w-5 h-5 text-gray-700" />}
      </button>

      <div className="min-h-screen flex items-center justify-center p-4">
        <div className="w-full max-w-5xl">
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            
            {/* فرم سمت چپ */}
            <div className="order-1 bg-white dark:bg-gray-900 rounded-2xl shadow-2xl p-6 sm:p-8 flex flex-col justify-center min-h-[600px] transition-colors duration-300">
              {step === "send" ? (
                <SendOtpForm onSendOtp={handleSendOtp} />
              ) : (
                <VerifyOtpForm 
                  phone={phone} 
                  onBack={() => {
                    setStep("send");
                    setPhone("");
                  }} 
                  onVerify={handleVerify} 
                />
              )}
            </div>

            {/* کاروسل سمت راست */}
            <div className="order-2 hidden lg:block relative rounded-2xl overflow-hidden h-[600px] bg-gradient-to-br from-purple-600 to-pink-600 shadow-2xl">
              {slides.map((slide, index) => (
                <div
                  key={index}
                  className={`absolute inset-0 transition-all duration-1000 ${
                    currentSlide === index 
                      ? "opacity-100 scale-100" 
                      : "opacity-0 scale-110"
                  }`}
                >
                  <img
                    src={slide.image}
                    alt={slide.text}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
                  <div className="absolute bottom-12 left-0 right-0 text-center px-8">
                    <p className="text-white text-base font-medium max-w-xs mx-auto leading-relaxed">
                      {slide.text}
                    </p>
                  </div>
                </div>
              ))}
              
              <div className="absolute bottom-6 left-0 right-0 flex justify-center gap-2 z-10">
                {slides.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentSlide(index)}
                    className={`h-1 rounded-full transition-all duration-300 ${
                      currentSlide === index 
                        ? "w-6 bg-white" 
                        : "w-1.5 bg-white/50 hover:bg-white/70"
                    }`}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}